# MisionTIC2022-Ciclo2-Unidad4-JPA

Proyecto de ejemplo para la gestion de empleados usando JPA en una Base de Datos SQLite
