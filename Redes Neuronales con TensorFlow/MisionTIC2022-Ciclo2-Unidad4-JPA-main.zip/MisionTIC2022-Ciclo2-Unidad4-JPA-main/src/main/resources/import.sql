insert into departments values (1, 'Administrativa');
insert into departments values (2, 'Financiera');
insert into departments values (3, 'Compras');
insert into departments values (4, 'Ventas');
insert into departments values (5, 'Inventario');