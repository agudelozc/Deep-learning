package co.edu.utp.misiontic2022.c2.cdiaz;

import co.edu.utp.misiontic2022.c2.cdiaz.view.MainMenu;

/**
 * Hello world!
 *
 */
public class App {
    public static void main(String[] args) {
        MainMenu.start();
    }

}
